/*
 * macros.h
 *
 *  Created on: 21 dec. 2017
 *      Author: Robbe
 */

#ifndef MACROS_H_
#define MACROS_H_

#define CHECK_BIT(var,pos) ((var) & (1<<(pos)))

#endif /* MACROS_H_ */
